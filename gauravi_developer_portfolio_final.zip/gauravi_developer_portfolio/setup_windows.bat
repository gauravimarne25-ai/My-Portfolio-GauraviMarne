@echo off
cd /d "%~dp0"
py -3 -m venv .venv
if errorlevel 1 (echo Install Python 3.10+ and enable Add Python to PATH.& pause & exit /b 1)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (echo Dependency installation failed. Check internet connection.& pause & exit /b 1)
echo Setup complete. Run run_desktop.bat or run_web.bat.
pause
