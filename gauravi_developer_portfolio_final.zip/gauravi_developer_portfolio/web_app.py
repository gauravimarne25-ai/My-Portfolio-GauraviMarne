from pathlib import Path
import json
from flask import Flask, render_template, abort
ROOT=Path(__file__).resolve().parent
app=Flask(__name__,template_folder=str(ROOT/'web'/'templates'),static_folder=str(ROOT/'web'/'static'))
def data():
 with (ROOT/'data'/'portfolio.json').open(encoding='utf-8') as f:return json.load(f)
@app.get('/')
def home():
 d=data(); return render_template('index.html',profile=d['profile'],projects=d['projects'],skills=d['skills'])
@app.get('/projects/<project_id>')
def detail(project_id):
 d=data(); p=next((x for x in d['projects'] if x.get('id')==project_id),None)
 if p is None:abort(404)
 return render_template('project.html',profile=d['profile'],project=p)
if __name__=='__main__':app.run(host='127.0.0.1',port=5000,debug=False)
