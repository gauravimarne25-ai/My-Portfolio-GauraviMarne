# Gauravi Marne — Advanced Developer Portfolio Studio

A polished glassmorphism portfolio with a Python desktop GUI (PySide6) and a responsive companion website (Flask). Both interfaces share `data/portfolio.json`. It includes a profile-photo slot, project-output galleries, searchable/editable projects, skill groups, and individual project pages.

## Run on Windows / VS Code
1. Extract the ZIP and open the extracted `gauravi_developer_portfolio` folder in VS Code.
2. Open **Terminal → New Terminal**.
3. Run:

   ```powershell
   py -3 -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

   If PowerShell blocks activation, double-click `setup_windows.bat`. Activation is optional; use `\.venv\Scripts\python.exe` directly.
4. Start the desktop GUI:

   ```powershell
   .\.venv\Scripts\python.exe app.py
   ```
5. For the website, open a second terminal and run:

   ```powershell
   .\.venv\Scripts\python.exe web_app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser.

## Add your own pictures later

All image slots are already created and visible in both the web portfolio and the desktop project cards.

- **Your profile picture:** replace `web/static/images/profile-photo.jpg` with your own square JPG photo. Keep the filename unchanged.
- **Network Failure Diagnosis output:** replace `web/static/images/network-failure-output.jpg` with a screenshot of your real project output/dashboard. Use a 16:9 image where possible.
- **Federated Learning Recommender output:** replace `web/static/images/federated-recommender-output.jpg` with a screenshot of your actual output or MLflow view.

The current JPGs are labelled placeholder graphics so they are easy to identify. To add more screenshots, add image files under `web/static/images/` and add entries to the relevant project's `screenshots` array in `data/portfolio.json`, using paths relative to `web/static/`, for example `images/my-new-output.jpg`. Set a short `caption` and descriptive `alt` text too. Refresh the browser after replacing images.

## Features
- Advanced responsive dark glassmorphism design with gradients, hover effects, image gallery cards, and mobile layout.
- Desktop GUI built with PySide6 and a companion Flask website.
- Profile photo slot and screenshot previews for both featured projects.
- Search, add, edit, and delete projects from the desktop app.
- Edit profile, social links, education, and bio; shared JSON data keeps both interfaces in sync.
- Project detail pages with screenshot gallery, technology tags, focus areas, and optional source/demo links.
- Editable skills, certifications, and achievements.

## Customize before publishing
- Add your professional email and personalize your bio.
- Add real GitHub/demo URLs and replace screenshot placeholders with genuine project outputs.
- Update project descriptions, implementation details, datasets, and metrics to match what you actually built.
- Add verified certifications/achievements only. Never claim features or results you cannot demonstrate.
- The Flask server is intended for local development, not production deployment.

## One-click launch
- `setup_windows.bat`: install dependencies once.
- `run_desktop.bat`: open desktop app.
- `run_web.bat`: start local website.

## Troubleshooting
- `py` not found: install Python 3.10+ and enable **Add Python to PATH**.
- Missing PySide6/Flask: run `pip install -r requirements.txt` inside the project environment.
- Website not loading: keep `web_app.py` running and visit `http://127.0.0.1:5000`.
- Port 5000 busy: close the other local server or change the port in `web_app.py`.


## Certificates and resume
The Certificates section includes the two supplied certificate PDFs and links to their Coursera verification pages. A starter one-page resume PDF is included at `web/static/documents/gauravi_santosh_marne_resume.pdf`. Review it and add a professional email address or other details you want before submitting it. Achievements have been removed from the portfolio.
