import json, sys, webbrowser, re
from pathlib import Path
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QFrame,QStackedWidget,QScrollArea,QGridLayout,QLineEdit,QTextEdit,QComboBox,QMessageBox,QDialog,QFormLayout,QDialogButtonBox)
ROOT=Path(__file__).resolve().parent; DATA=ROOT/'data'/'portfolio.json'
STYLE="""
QMainWindow,QWidget#root{background:#0b1020;color:#edf2ff;font-family:'Segoe UI';font-size:10pt} QWidget{color:#edf2ff}
QFrame#sidebar{background:rgba(20,27,51,235);border:1px solid #293454;border-radius:18px}
QFrame#panel,QFrame#statCard,QFrame#projectCard{background:rgba(24,33,61,220);border:1px solid #354365;border-radius:16px}
QLabel#eyebrow{color:#a5b4fc;font-size:9pt} QLabel#heroTitle{font-size:25pt;font-weight:700} QLabel#sectionTitle{font-size:16pt;font-weight:700} QLabel#statValue{font-size:22pt;font-weight:700;color:#a5b4fc} QLabel#muted{color:#aab7d5}
QPushButton{background:#273454;border:1px solid #3b4b70;border-radius:10px;padding:10px 13px;text-align:left} QPushButton:hover{background:#35466e;border-color:#8b9bf7} QPushButton#primary{background:#6558e8;border:1px solid #8a80ff;font-weight:600} QPushButton#nav{background:transparent;border:1px solid transparent;padding:12px} QPushButton#nav:checked{background:#2b355a;border:1px solid #5e6ca1}
QLineEdit,QTextEdit,QComboBox{background:#111a31;border:1px solid #3a496d;border-radius:8px;padding:8px} QScrollArea{border:none;background:transparent} QDialog,QMessageBox{background:#10182e}
"""
def read(): return json.loads(DATA.read_text(encoding='utf-8'))
def save(d):
    tmp=DATA.with_suffix('.tmp'); tmp.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf-8'); tmp.replace(DATA)
def lbl(t,n=None,w=False):
    x=QLabel(t); x.setWordWrap(w)
    if n:x.setObjectName(n)
    return x
class ProjectDialog(QDialog):
 def __init__(self,p=None,parent=None):
  super().__init__(parent); self.p=p or {}; self.setWindowTitle('Project details'); self.setMinimumWidth(510); box=QVBoxLayout(self); form=QFormLayout()
  self.name=QLineEdit(self.p.get('name','')); self.summary=QTextEdit(self.p.get('summary','')); self.summary.setFixedHeight(65); self.desc=QTextEdit(self.p.get('description','')); self.desc.setFixedHeight(75); self.tech=QLineEdit(', '.join(self.p.get('technologies',[]))); self.status=QComboBox(); self.status.addItems(['In progress','Completed','Prototype','On hold']); self.status.setCurrentText(self.p.get('status','In progress')); self.gh=QLineEdit(self.p.get('github_url','')); self.demo=QLineEdit(self.p.get('demo_url',''))
  for t,w in [('Project name *',self.name),('Summary *',self.summary),('Details',self.desc),('Technologies, comma-separated',self.tech),('Status',self.status),('GitHub URL',self.gh),('Demo URL',self.demo)]:form.addRow(t,w)
  box.addLayout(form); buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); buttons.accepted.connect(self.check); buttons.rejected.connect(self.reject); box.addWidget(buttons)
 def check(self):
  if not self.name.text().strip() or not self.summary.toPlainText().strip(): QMessageBox.warning(self,'Required','Project name and summary are required.'); return
  self.accept()
 def result_data(self):
  name=self.name.text().strip(); slug=re.sub(r'[^a-z0-9]+','-',name.lower()).strip('-') or 'project'
  return {'id':self.p.get('id',slug),'name':name,'summary':self.summary.toPlainText().strip(),'description':self.desc.toPlainText().strip(),'technologies':[s.strip() for s in self.tech.text().split(',') if s.strip()],'status':self.status.currentText(),'github_url':self.gh.text().strip(),'demo_url':self.demo.text().strip(),'highlights':self.p.get('highlights',[]),'screenshots':self.p.get('screenshots',[{'path':'images/project-output-placeholder.jpg','caption':'Project output screenshot','alt':'Project output placeholder'}])}
class Window(QMainWindow):
 def __init__(self):
  super().__init__(); self.setWindowTitle('Gauravi Marne | Developer Portfolio'); self.resize(1260,820); self.setMinimumSize(980,640); root=QWidget(); root.setObjectName('root'); self.setCentralWidget(root); outer=QHBoxLayout(root); outer.setContentsMargins(18,18,18,18); outer.setSpacing(15)
  side=QFrame(); side.setObjectName('sidebar'); side.setFixedWidth(220); sl=QVBoxLayout(side); sl.setContentsMargins(16,20,16,16); sl.addWidget(lbl('GM','statValue')); sl.addWidget(lbl('PORTFOLIO STUDIO','eyebrow')); sl.addSpacing(14); self.nav=[]
  for title,i in [('⌂  Overview',0),('▦  Projects',1),('✧  Skills',2),('▤  Certificates',3),('◉  Profile',4)]:
   b=QPushButton(title); b.setObjectName('nav'); b.setCheckable(True); b.clicked.connect(lambda checked=False,j=i:self.page(j)); sl.addWidget(b); self.nav.append(b)
  sl.addStretch(); sl.addWidget(lbl('GLASSMORPHISM UI','eyebrow')); sl.addWidget(lbl('Your work. Your story.\nYour next opportunity.','muted',True)); wb=QPushButton('↗ Open web portfolio'); wb.setObjectName('primary'); wb.clicked.connect(self.open_web); sl.addWidget(wb); outer.addWidget(side)
  self.stack=QStackedWidget(); outer.addWidget(self.stack,1); self.pages=[]
  for i in range(5):
   p=QWidget(); s=QScrollArea(); s.setWidgetResizable(True); s.setWidget(p); self.stack.addWidget(s); self.pages.append(p)
  self.page(0)
 def layout(self,i):
  p=self.pages[i]
  if p.layout(): QWidget().setLayout(p.layout())
  l=QVBoxLayout(p); l.setContentsMargins(12,10,12,20); l.setSpacing(15); return l
 def panel(self,title,body):
  f=QFrame(); f.setObjectName('panel'); l=QVBoxLayout(f); l.setContentsMargins(18,16,18,16); l.addWidget(lbl(title,'sectionTitle')); l.addWidget(body); return f
 def stat(self,n,t):
  f=QFrame(); f.setObjectName('statCard'); l=QVBoxLayout(f); l.setContentsMargins(17,15,17,15); l.addWidget(lbl(str(n),'statValue')); l.addWidget(lbl(t,'muted')); return f
 def page(self,i):
  self.d=read(); self.stack.setCurrentIndex(i)
  for j,b in enumerate(self.nav):b.setChecked(j==i)
  [self.overview,self.projects,self.skills,self.certificates,self.profile][i]()
 def overview(self):
  d=read(); p=d['profile']; l=self.layout(0); l.addWidget(lbl('DEVELOPER WORKSPACE / OVERVIEW','eyebrow')); hero=QFrame(); hero.setObjectName('panel'); h=QVBoxLayout(hero); h.setContentsMargins(25,25,25,25); hero_row=QHBoxLayout(); hero_text=QVBoxLayout(); hero_text.addWidget(lbl("Hello, I'm "+p['name'],'heroTitle',True)); hero_text.addWidget(lbl(p['title'],'sectionTitle')); hero_text.addWidget(lbl(p['about'],'muted',True)); hero_row.addLayout(hero_text,1); photo_path=ROOT/'web'/'static'/p.get('photo_path','images/profile-photo.jpg'); photo=QLabel(); photo.setAlignment(__import__('PySide6.QtCore',fromlist=['Qt']).Qt.AlignCenter); pix=QPixmap(str(photo_path)); photo.setPixmap(pix.scaled(155,155,__import__('PySide6.QtCore',fromlist=['Qt']).Qt.KeepAspectRatio,__import__('PySide6.QtCore',fromlist=['Qt']).Qt.SmoothTransformation) if not pix.isNull() else QPixmap()); photo.setFixedSize(165,165); photo.setStyleSheet('border:2px solid #6573b7;border-radius:18px;background:#111a31'); hero_row.addWidget(photo); h.addLayout(hero_row); row=QHBoxLayout(); a=QPushButton('Explore projects →'); a.setObjectName('primary'); a.clicked.connect(lambda:self.page(1)); b=QPushButton('Edit profile'); b.clicked.connect(lambda:self.page(3)); row.addWidget(a); row.addWidget(b); row.addStretch(); h.addLayout(row); l.addWidget(hero)
  stats=QHBoxLayout(); stats.addWidget(self.stat(len(d['projects']),'Projects listed')); stats.addWidget(self.stat(len(d['skills']),'Skills listed')); stats.addWidget(self.stat(len(p.get('certifications',[])),'Certifications added')); l.addLayout(stats)
  grid=QGridLayout(); grid.addWidget(self.panel('Education',lbl(p['education']+'\n'+p['university'],'muted',True)),0,0); grid.addWidget(self.panel('Current focus',lbl('Software engineering • AI/ML • Practical projects\n\nAdd verified links, implementation notes, and demos in Projects.','muted',True)),0,1); l.addLayout(grid)
 def projects(self):
  l=self.layout(1); head=QHBoxLayout(); head.addWidget(lbl('Projects','sectionTitle')); head.addStretch(); add=QPushButton('+ Add project'); add.setObjectName('primary'); add.clicked.connect(self.add); head.addWidget(add); l.addLayout(head); search=QLineEdit(); search.setPlaceholderText('Search project, technology, or status…'); l.addWidget(search); container=QWidget(); cards=QVBoxLayout(container); cards.setContentsMargins(0,0,0,0); cards.setSpacing(12)
  def populate(q=''):
   while cards.count():
    item=cards.takeAt(0)
    if item.widget():item.widget().deleteLater()
   ps=read()['projects']; q=q.lower().strip(); ps=[p for p in ps if q in (p['name']+' '+p['summary']+' '+p.get('status','')+' '+' '.join(p.get('technologies',[]))).lower()]
   if not ps:cards.addWidget(lbl('No matches. Try another search or add a project.','muted',True))
   for p in ps:
    f=QFrame(); f.setObjectName('projectCard'); v=QVBoxLayout(f); top=QHBoxLayout(); top.addWidget(lbl(p['name'],'sectionTitle',True),1); top.addWidget(lbl(p.get('status','In progress'),'eyebrow')); v.addLayout(top); shots=p.get('screenshots',[]);
    if shots:
     shot=QLabel(); shot.setAlignment(__import__('PySide6.QtCore',fromlist=['Qt']).Qt.AlignCenter); sp=ROOT/'web'/'static'/shots[0].get('path',''); pm=QPixmap(str(sp));
     if not pm.isNull(): shot.setPixmap(pm.scaled(620,230,__import__('PySide6.QtCore',fromlist=['Qt']).Qt.KeepAspectRatio,__import__('PySide6.QtCore',fromlist=['Qt']).Qt.SmoothTransformation))
     else: shot.setText('Add screenshot in web/static/images/'); shot.setStyleSheet('border:1px solid #354365;border-radius:10px;background:#111a31;color:#aab7d5'); shot.setMinimumHeight(140); v.addWidget(shot)
    v.addWidget(lbl(p['summary'],'muted',True)); v.addWidget(lbl(' • '.join(p.get('technologies',[])),'eyebrow',True)); v.addWidget(lbl(p.get('description',''),'muted',True)); row=QHBoxLayout(); e=QPushButton('Edit'); e.clicked.connect(lambda checked=False,x=p:self.edit(x)); row.addWidget(e)
    for title,key in [('GitHub ↗','github_url'),('Demo ↗','demo_url')]:
     url=p.get(key,'')
     if url:
      b=QPushButton(title); b.clicked.connect(lambda checked=False,u=url:webbrowser.open(u)); row.addWidget(b)
    de=QPushButton('Delete'); de.clicked.connect(lambda checked=False,x=p:self.delete(x)); row.addWidget(de); row.addStretch(); v.addLayout(row); cards.addWidget(f)
   cards.addStretch()
  search.textChanged.connect(populate); l.addWidget(container); populate()
 def add(self):
  x=ProjectDialog(parent=self)
  if x.exec()==QDialog.Accepted:d=read(); d['projects'].append(x.result_data()); save(d); self.page(1)
 def edit(self,p):
  x=ProjectDialog(p,self)
  if x.exec()==QDialog.Accepted:
   d=read(); new=x.result_data(); d['projects']=[new if q.get('id')==p.get('id') else q for q in d['projects']]; save(d); self.page(1)
 def delete(self,p):
  if QMessageBox.question(self,'Delete project',f"Delete '{p['name']}'?")==QMessageBox.Yes:d=read(); d['projects']=[x for x in d['projects'] if x.get('id')!=p.get('id')]; save(d); self.page(1)
 def skills(self):
  d=read(); l=self.layout(2); l.addWidget(lbl('Skills & toolkit','sectionTitle')); l.addWidget(lbl('Edit skills in data/portfolio.json. List skills you can confidently discuss.','muted',True)); groups={}
  for s in d['skills']:groups.setdefault(s.get('category','Other'),[]).append(s['name'])
  grid=QGridLayout()
  for i,(cat,names) in enumerate(groups.items()):grid.addWidget(self.panel(cat,lbl(' • '.join(names),'muted',True)),i//2,i%2)
  l.addLayout(grid); l.addStretch()
 def certificates(self):
  d=read(); l=self.layout(3); l.addWidget(lbl('Certificates & resume','sectionTitle')); l.addWidget(lbl('Open the original certificate PDFs or your generated resume. Files are stored under web/static/.','muted',True))
  for c in d['profile'].get('certifications',[]):
   f=QFrame(); f.setObjectName('panel'); v=QVBoxLayout(f); v.addWidget(lbl(c['title'],'sectionTitle',True)); v.addWidget(lbl(c['issuer']+' • '+c['date'],'eyebrow')); v.addWidget(lbl(c.get('description',''),'muted',True)); row=QHBoxLayout(); b=QPushButton('Open certificate PDF'); b.clicked.connect(lambda checked=False,path=c['file']:webbrowser.open((ROOT/'web'/'static'/path).resolve().as_uri())); row.addWidget(b); row.addStretch(); v.addLayout(row); l.addWidget(f)
  f=QFrame(); f.setObjectName('panel'); v=QVBoxLayout(f); v.addWidget(lbl('Resume — Gauravi Santosh Marne','sectionTitle')); b=QPushButton('Open / view resume PDF'); b.clicked.connect(lambda:webbrowser.open((ROOT/'web'/'static'/d['profile']['resume_path']).resolve().as_uri())); v.addWidget(b); l.addWidget(f); l.addStretch()
 def profile(self):
  p=read()['profile']; l=self.layout(4); l.addWidget(lbl('Profile settings','sectionTitle')); l.addWidget(lbl('Changes are saved to the shared JSON file and appear on the web portfolio. Replace web/static/images/profile-photo.jpg with your own square photo.','muted',True)); f=QFrame(); f.setObjectName('panel'); form=QFormLayout(f); form.setContentsMargins(20,20,20,20); fields={}
  for key,title in [('name','Full name'),('title','Professional title'),('education','Education'),('university','University'),('email','Email / contact'),('location','Location'),('github','GitHub URL'),('linkedin','LinkedIn URL'),('resume_path','Resume file path')]:fields[key]=QLineEdit(p.get(key,'')); form.addRow(title,fields[key])
  about=QTextEdit(p.get('about','')); about.setMinimumHeight(100); form.addRow('About me',about); l.addWidget(f); savebtn=QPushButton('Save profile changes'); savebtn.setObjectName('primary')
  def commit():
   d=read()
   for k,w in fields.items():d['profile'][k]=w.text().strip()
   d['profile']['about']=about.toPlainText().strip(); save(d); QMessageBox.information(self,'Saved','Profile updated.'); self.page(3)
  savebtn.clicked.connect(commit); l.addWidget(savebtn); row=QHBoxLayout()
  for title,key in [('Open GitHub ↗','github'),('Open LinkedIn ↗','linkedin')]:
   b=QPushButton(title); b.clicked.connect(lambda checked=False,k=key:webbrowser.open(read()['profile'][k])); row.addWidget(b)
  row.addStretch(); l.addLayout(row); l.addStretch()
 def open_web(self):
  webbrowser.open('http://127.0.0.1:5000'); QMessageBox.information(self,'Web portfolio','If the site is not running, open a second terminal and run: python web_app.py\nThen visit http://127.0.0.1:5000')
def main():
 app=QApplication(sys.argv); app.setStyle('Fusion'); app.setFont(QFont('Segoe UI',10)); app.setStyleSheet(STYLE); w=Window(); w.show(); sys.exit(app.exec())
if __name__=='__main__':main()
