import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PortfolioDataTests(unittest.TestCase):
    def setUp(self):
        self.data = json.loads((ROOT / "data" / "portfolio.json").read_text(encoding="utf-8"))

    def test_profile_has_core_fields(self):
        for field in ("name", "title", "education", "github", "linkedin", "photo_path"):
            self.assertTrue(self.data["profile"].get(field), field)

    def test_projects_have_unique_ids_and_screenshot_slots(self):
        projects = self.data["projects"]
        ids = [p["id"] for p in projects]
        self.assertEqual(len(ids), len(set(ids)))
        for project in projects:
            self.assertTrue(project.get("screenshots"), project["id"])
            for shot in project["screenshots"]:
                self.assertTrue((ROOT / "web" / "static" / shot["path"]).exists(), shot["path"])

    def test_profile_photo_slot_exists(self):
        self.assertTrue((ROOT / "web" / "static" / self.data["profile"]["photo_path"]).exists())

if __name__ == "__main__":
    unittest.main()
